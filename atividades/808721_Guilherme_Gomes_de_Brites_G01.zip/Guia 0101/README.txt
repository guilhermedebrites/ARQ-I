Arquitetura de Computadores I
808721 - Guilherme Gomes de Brites

Exercicio extra pode ser encontrado dentro da pasta 
Guia_01 -> src -> Guia_01.java

Feito em java, utilizando os modelos disponiveis o programa realiza as conversões e confere, podendo retornar erros caso a conversão esteja errada.

Todos os exercicios feitos manualmente podem ser encontrados no arquivo Guia_01.txt